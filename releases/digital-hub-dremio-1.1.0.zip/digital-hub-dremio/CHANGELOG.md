# Changelog

## 1.0.0 (Unreleased)

Initial release.

## 1.0.1 (Unreleased)

Support for variable interpolation in queries.

## 1.0.2 (Unreleased)

Support for query variables, paginated jobs handling.

## 1.0.3 (Unreleased)

Support for custom maximum number of records to fetch as query results.

## 1.1.0 (Unreleased)

Migration from grafana-toolkit to create-plugin tool for plugin management.
