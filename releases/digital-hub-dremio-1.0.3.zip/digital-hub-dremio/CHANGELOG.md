# Changelog

## 1.0.0 (Unreleased)

Initial release.

## 1.0.1 (Unreleased)

Support for variable interpolation in queries.

## 1.0.2 (Unreleased)

Support for query variables, paginated jobs handling.
